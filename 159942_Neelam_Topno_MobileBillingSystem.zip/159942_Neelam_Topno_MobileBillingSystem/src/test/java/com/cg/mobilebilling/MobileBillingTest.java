package com.cg.mobilebilling;
import java.util.ArrayList;
import org.easymock.EasyMock;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.daoservices.BillingDAOServices;
import com.cg.mobilebilling.daoservices.CustomerDAOServices;
import com.cg.mobilebilling.daoservices.PlanDAOServices;
import com.cg.mobilebilling.daoservices.PostpaidAccountDAOServices;
import com.cg.mobilebilling.services.BillingServices;
import com.cg.mobilebilling.services.BillingServicesImpl;
public class MobileBillingTest {
	@Mock
	private static BillingServices billingServices;
	private  static BillingDAOServices mockBillingDAOServices;
	private static CustomerDAOServices mockCustomerDAOServices;
	private static PlanDAOServices mockPlanDAOServices;
	private static PostpaidAccountDAOServices mockPostpaidAccountDAOServices;
	@BeforeClass
	public static void setUpTestEnv() {
	
		mockBillingDAOServices = EasyMock.createMock(BillingDAOServices.class);
		mockCustomerDAOServices=EasyMock.createMock(CustomerDAOServices.class);
		mockPlanDAOServices=EasyMock.createMock(PlanDAOServices.class);
		mockPostpaidAccountDAOServices=EasyMock.createMock(PostpaidAccountDAOServices.class);
		billingServices=new BillingServicesImpl(mockBillingDAOServices);
		billingServices=new BillingServicesImpl(mockCustomerDAOServices);
		billingServices=new BillingServicesImpl(mockPlanDAOServices);
		billingServices=new BillingServicesImpl(mockPostpaidAccountDAOServices);
	}
	
	@Test
	public void setUpTestData() {	
		Customer customer1=new Customer(1001, "Ashav", "Kumar", "ashav21011996@gmail.com", "21/01/1996", new Address(282006, "Agra", "UP"));
		
		//Customer customer2=new Customer(1002, "Keshav", "Agrawal", "keshav.agrawal@capgemini.com", "11/07/1996", new Address(838101, "JSR", "Jharkhand"));
		
		
		ArrayList<Customer> customerList = new ArrayList<>();
		customerList.add(customer1);
		//customerList.add(customer2);
		
		new Customer( 1003, "Neelam", "Topno", "neelam.topno@capgemini.com", "11/1/1997",new Address(816222, "Bokaro", "Jharkhand"));
		EasyMock.expect(mockCustomerDAOServices.findById(1001).get()).andReturn(customer1);
		//EasyMock.expect(mockCustomerDAOServices.findById(1002).get()).andReturn(customer2);
		EasyMock.expect(mockCustomerDAOServices.findById(1000).get()).andReturn(null);
		
		//EasyMock.expect(mockCustomerDAOServices.findAll()).andReturn(customerList);
		
		
		//EasyMock.expect(mockCustomerDAOServices.save(customer3)).andReturn(customer3);
		
		
	}

	/*@Test(expected = CustomerDetailsNotFoundException.class)
	public void testGetAssociateDataForInvalidAssociateId() throws CustomerDetailsNotFoundException, BillingServicesDownException {
		billingServices.getCustomerDetails(1000);
		
		EasyMock.verify(mockCustomerDAOServices.findById(1000));
	}
	
	
	@Test
	public void testGetAssociateDataForValidAssociateId() throws CustomerDetailsNotFoundException, BillingServicesDownException{
		Customer expectedCustomer = new Customer(1001, "Ashav", "Kumar", "ashav21011996@gmail.com", "21/01/1996",new Address(282006, "Agra","UP"));
		Customer actualCustomer = billingServices.getCustomerDetails(1001);
		EasyMock.verify(mockCustomerDAOServices.findById(1001));
		assertEquals(expectedCustomer, actualCustomer);
	}

	@Test
	public void testAcceptAssociateDetailsForValidData() throws BillingServicesDownException {
		int expectedCustomerId = 1003;
		
		Customer customer=new Customer(1003, "Ashav", "Kumar", "ashav21011996@gmail.com", "21/01/1996", new Address(282006, "Agra", "UP"));
		int actualCustomerId=billingServices.acceptCustomerDetails(customer);
		assertEquals(expectedCustomerId, actualCustomerId);
	}
*/
	/*@Test(expected = AssociateDetailsNotFoundException.class)
	public void testCalculateNetSalaryForInvalidAssociateId()
			throws PayrollServicesDownException, AssociateDetailsNotFoundException {
		payrollServices.getAssociateDetails(63363);
	}

	@Test
	public void testCalculateNetSalaryForValidAssociateId() {
		fail();
	}

	@Test
	public void testGetAllAssociatesDetails() throws PayrollServicesDownException {
		Associate associate1 = new Associate(1001, 78000, "Satish", "Mahajan", "Training", "Manager", "DTDYF736",
				"satish.mahajan@capgemini.com",new BankDetails(12345, "HDFC", "HDFC0097"), new Salary(35000, 1800, 1800)
				);
		Associate associate2 =new Associate(1002, 87372, "Ayush", "Mahajan", "Training", "Manager", "YCTCC727",
				"ayush.mahajan@capgemini.com", new BankDetails(12345, "HDFC", "HDFC0097"),new Salary(87738, 1800, 1800)
				);
		ArrayList<Associate> expectedAssociateList = new ArrayList<>();
		expectedAssociateList.add(associate1);
		expectedAssociateList.add(associate2);
		
		
		ArrayList<Associate> actualAssociateList = payrollServices.getAllAssociatesDetails();
		assertEquals(expectedAssociateList,actualAssociateList);
	}
	@After
	public void tearDownTestData() {
		
	}
	
	@AfterClass
	public static void tearDownTestEnv() {
		mockAssociateDao=null;
		payrollServices=null;
	}*/
}
